                =====================================
                SoundFont(R) Enabler Software Package
                =====================================

This data should have been unzipped with the directory structure in tact.

All source code files for the SoundFont Enabler are in the 'src' subdirectory.

All header files are in the 'include' subdirectory. 

A document in MS Word 5 format is in the 'doc' subdirectory. 

The SoundFont Compatability Validation Suite is in the 'data' subdirectory. 

The SoundFont Enabler with Menu Driven interface compiled in DOS format
executable called 'enabdrv.exe' is in the current directory.

The enclosed example software is "Copyright (C) 1994-1995, E-mu Systems, 
Inc./Creative Technologies Ltd. All Rights Reserved". License is hereby
granted by the copyright holder to copy and use this code for the
purposes of developing SoundFont compatible software. This software may
NOT be distributed or used for other purposes without written consent from
E-mu Systems, Inc. or Creative Technologies, Ltd. This software and 
information is provided "as is" without warranty of any kind, either
expressed or implied, including but not limited to the implied warranties
of merchantability and/or fitness for a particular purpose.

SoundFont Enabler Software Design and Authoring:
Robert S. Crawford
Mike Guzewicz
Matt Williams

Technical Contributions:
Alvin Khor        
Khir Hien Tan   
David O'Neal
Dave Rossum
Don Ruffcorn
Lee Teck Seng

